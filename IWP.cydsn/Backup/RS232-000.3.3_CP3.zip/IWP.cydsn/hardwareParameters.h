/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#ifndef HARDWARE_PARAMETERS_H
#define HARDWARE_PARAMETERS_H    
    
#define SHOULDER_DEC_RES 2048
#define MOTOR_DEC_RES 64
    
#endif
/* [] END OF FILE */
