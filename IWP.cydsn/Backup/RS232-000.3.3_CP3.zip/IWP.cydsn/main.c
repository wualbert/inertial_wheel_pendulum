/* ========================================
 *
 * Copyright Albert Wu, 2018
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF MIT 6.115.
 *
 * This file is necessary for your project to build.
 * Please do not delete it.
 *
 * ========================================
*/
#define TEST

#include <device.h>
#include "adc.h"
#ifdef TEST
    #include "test.h"
#endif

CY_ISR(RX_INT)
{
    LCD_PutChar(UART_ReadRxData());     // RX ISR
}

void main()
{	
    #ifdef TEST
        //sensor testing mode
        //initialize sensors
        LCD_Start();					    // initialize lcd
    	LCD_ClearDisplay();
        initADC();
        initQuadDec();
        
        int pause = 2000;
        while(1)
        {
            testMotorDec();
            CyDelay(pause);
            testShoulderDec();
            CyDelay(pause);
            testADC(1);
            CyDelay(pause);
            testADC(2);
            CyDelay(pause);
        }
        
    #endif
    
    #ifndef TEST
        //regular operation
        LCD_Start();					    // initialize lcd
    	LCD_ClearDisplay();
        
        CyGlobalIntEnable;
        rx_int_StartEx(RX_INT);             // start RX interrupt (look for CY_ISR with RX_INT address)
                                            // for code that writes received bytes to LCD.
        
        UART_Start();                       // initialize UART
        UART_ClearRxBuffer();
    
    #endif    
}

/* [] END OF FILE */