/* ========================================
 *
 * Copyright Albert Wu, 2018
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "quadDec.h"

void initQuadDec()
{
    QuadDec_Motor_Start();
    QuadDec_Shoulder_Start();
    
    //Zero the decoders
    QuadDec_Motor_SetCounter(0);
    QuadDec_Shoulder_SetCounter(0);
}

int16 getMotorDecReading()
{
    return QuadDec_Motor_GetCounter();
}
int16 getShoulderDecReading()
{
    return QuadDec_Shoulder_GetCounter();
}

/* [] END OF FILE */
