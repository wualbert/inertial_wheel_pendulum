/* ========================================
 *
 * Copyright Albert Wu, 2018
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "adc.h"

void initADC()
{
    //Initalizes ADCs
    ADC1_Start();
    ADC2_Start();
}
int16 getADCReading(int adcID)
{
    switch(adcID)
    {
        case 1:        
            ADC1_StartConvert();                          //start conversion
            ADC1_IsEndConversion(ADC1_WAIT_FOR_RESULT);   //wait for finish
            return ADC1_GetResult16();
            break;
            
        case 2:
            ADC2_StartConvert();                        //start conversion
            ADC2_IsEndConversion(ADC2_WAIT_FOR_RESULT);   //wait for finish
            return ADC2_GetResult16();         
            break;
    }
    return 0;
}





/* [] END OF FILE */
