/* ========================================
 *
 * Copyright Albert Wu, 2018
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#include "test.h"
#include "quadDec.h"
#include "adc.h"
#include <string.h>

void testMotorDec()
{
    LCD_ClearDisplay();
    LCD_PrintString("Mtr Dec: ");
    LCD_Position(1, 0);  //line feed
    LCD_PrintNumber(getMotorDecReading());

}
void testShoulderDec()
{
    LCD_ClearDisplay();
    LCD_PrintString("Shdr Dec: ");
    LCD_Position(1, 0);  //line feed
    LCD_PrintNumber(getShoulderDecReading());    

}
void testADC(int adcID)
{
    LCD_ClearDisplay();
    LCD_PrintString("ADC ");
    LCD_PrintNumber(adcID);
    LCD_PrintString(": ");
	LCD_Position(1, 0);  //line feed
    LCD_PrintNumber(getADCReading(adcID));
    
}
void testComm()
{
    
}
/* [] END OF FILE */
