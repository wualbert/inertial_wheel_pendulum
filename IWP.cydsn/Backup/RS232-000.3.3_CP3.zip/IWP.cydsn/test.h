/* ========================================
 *
 * Copyright Albert Wu, 2018
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef TEST_H
#define TEST_H

#include<project.h>
#include <device.h>

void testMotorDec();
void testShoulderDec();
void testADC(int adcID);
void testComm();

#endif
/* [] END OF FILE */
