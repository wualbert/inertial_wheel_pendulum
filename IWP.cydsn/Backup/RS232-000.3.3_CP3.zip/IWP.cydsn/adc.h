/* ========================================
 *
 * Copyright Albert Wu, 2018
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/

#ifndef ADC_H
#define ADC_H
#include<project.h>
#include <device.h>

//ADC functions
void initADC();
int16 getADCReading(int adcID);
    
#endif
/* [] END OF FILE */
